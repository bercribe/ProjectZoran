---
id: 76
title: Winding down
date: 2019-04-12T17:07:04+00:00
author: mawz
layout: post
guid: http://www.projectzoran.com/?p=76
permalink: /2019/04/12/winding-down/
categories:
  - Uncategorized
---
This week, I finished my research poster for the [Umich Design Expo](https://mdp.engin.umich.edu/design-expo/). I think it looks much more professional and gets to its point more concisely.<figure class="wp-block-image">

<img loading="lazy" width="750" height="563" src="https://i2.wp.com/bercribehome.wpcomstaging.com/wp-content/uploads/2019/12/46528-project-zoran-2.jpg?resize=750%2C563&#038;ssl=1" alt="" class="wp-image-79" data-recalc-dims="1" /> </figure> 

<div class="wp-block-file">
  <a href="https://bercribehome.wpcomstaging.com/wp-content/uploads/2019/12/2b307-project-zoran-2.pdf">Project Zoran</a><a href="http://www.projectzoran.com/wp-content/uploads/2019/04/Project-Zoran-2.pdf" class="wp-block-file__button" download>Download</a>
</div>

I also decided the [CelesteBot](https://github.com/sc2ad/CelesteBot/tree/qlearning) README was in need of improvement. I updated it with some &#8220;getting started&#8221; information that would be helpful for new users.

Other than that, I just ran CelesteBot on Celeste level 1A for about 3,000 generations. I haven&#8217;t been able to find any settings that I think are holding it back, I believe the machine just needs to get lucky with the right mutation at this point. The only way for it to get lucky is by running the same data set for a long time, so that&#8217;s what I did. It hasn&#8217;t had a significant breakthrough yet, but you never know when it will figure out how to evolve.

That&#8217;s pretty much it, I&#8217;ve just been wrapping up and making it as easy as possible for a potential successor to pick up my work.
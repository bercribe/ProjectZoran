---
id: 88
title: 'Project Zoran &#8211; A speed running research project'
date: 2020-01-10T06:46:59+00:00
author: mawz
layout: revision
guid: https://bercribe.home.blog/2020/01/10/8-revision-v1/
permalink: /?p=88
---
<div class="wp-block-cover alignfull" style="background-image:url('https://bercribehome.wpcomstaging.com/wp-content/uploads/2019/12/mountaindawn.jpg');background-position:50% 50%;">
  <div class="wp-block-cover__inner-container">
    <p>
      <!--StartFragment-->
    </p>
    
    <h2>
      Statement of Purpose
    </h2>
    
    <p>
      This blog is intended to document the process of researching video game artificial intelligence using machine learning, with an end goal of developing a tool that will generate Tool Assisted Speedrun (TAS) Bots. <a href="https://www.youtube.com/watch?v=BEcv7BD1q9o">TASBots</a> are predefined hard coded programs that can play single player video games nearly perfectly. The problem is that they must be painstakingly created by hand. This process can take years, as the TASBot developers discover bugs and skips in their chosen game. I believe this process could be expedited by leveraging modern machine learning techniques.
    </p>
    
    <p>
    </p>
  </div>
</div>

<div style="height:20px;" aria-hidden="true" class="wp-block-spacer">
</div>

<div style="height:20px;" aria-hidden="true" class="wp-block-spacer">
</div>

<hr class="wp-block-separator is-style-wide" />

### Follow My Blog {.has-text-align-left}

<p class="has-text-align-left">
  Get new content delivered directly to your inbox.
</p>

<div class="wp-block-jetpack-subscriptions">
  <div class="jetpack_subscription_widget">
  </div>
</div>
---
id: 111
title: Presentation Prep
date: 2020-01-10T07:47:00+00:00
author: mawz
layout: revision
guid: https://bercribe.home.blog/2020/01/10/68-revision-v1/
permalink: /?p=111
---
This week, I wanted to get fast mode working again and set up some differentiation in game entities for CelesteBot&#8217;s vision.

Getting fast mode working again required some optimizations. I was able to identify the resource hog fairly quickly, it was the entity caching function that was run every frame. The function was wiping the cache manually and building it again every frame, which was slowing everything down. I changed it slightly so that instead of clearing the cache, it simply allocated new memory and used that, discarding the old memory. This helped significantly, but fast mode was still choppy at high speeds.

I decided it was time for some user facing settings. sc2ad had requested some settings for specifying the cache size, so I implemented those first. In addition, created a setting for specifying how fast the fast mode should be, as an integer multiplier of real time speed. Realizing that entities in Celeste don&#8217;t move fast enough to necessitate updates every frame, I also included a setting specifying how many frames to wait before updating the entity cache. The default is 10 frames, which is equivalent to 0.167 seconds. This change seems to work fine, and makes fast mode work great at 10x speed once more.

Lastly, I expanded the number of unique entities the bot would recognize through its vision to about 16. Everything present in 1A was covered, and I made it almost trivial to add new entities in the future. When the bot encounters entities that are uncategorized, it prints a message to the console specifying which entity to add and which enumerator to add it to. This should help when someone wants to run the bot on 2A in the future, for example. I made another pull request with my changes, the pull request is available [here](https://github.com/sc2ad/CelesteBot/pull/2).

Again, I ran the bot for a while with my changes in place. It got to generation 1,200 in the span of 20 hours, which is equivalent to 36,000 attempts. The population data file for generation 1,200 was 894 MB. It still didn&#8217;t make it past room 3, but it progressed a lot faster than before.

The rest of my work this week relates to the [UMich Design Expo](https://mdp.engin.umich.edu/design-expo/), at which I will present my findings with CelesteBot. I will have a poster with some of my key findings, and a computer running CelesteBot training live. I put together a draft of my poster, it is visible below.<figure class="wp-block-image">

<img loading="lazy" width="750" height="563" src="https://i0.wp.com/bercribehome.wpcomstaging.com/wp-content/uploads/2019/12/c4d78-project-zoran.jpg?resize=750%2C563&#038;ssl=1" alt="" class="wp-image-70" data-recalc-dims="1" /> </figure> 

<div class="wp-block-file">
  <a href="https://bercribehome.wpcomstaging.com/wp-content/uploads/2019/12/9577f-project-zoran.pdf">Project Zoran</a><a href="http://www.projectzoran.com/wp-content/uploads/2019/04/Project-Zoran.pdf" class="wp-block-file__button" download>Download</a>
</div>

Short post this week, but that&#8217;s about all that happened. Next week I&#8217;ll be finalizing my poster and making any last minute changes needed for CelesteBot.
---
id: 121
title: Home
date: 2021-09-04T03:37:22+00:00
author: mawz
layout: revision
guid: https://bercribehome.wpcomstaging.com/?p=121
permalink: /?p=121
---
<div class="wp-block-cover alignfull">
  <img loading="lazy" width="750" height="422" class="wp-block-cover__image-background wp-image-101" alt="" src="https://bercribehome.files.wordpress.com/2020/01/banner-blank.png?resize=750%2C422" style="object-position:50% 50%" data-object-fit="cover" data-object-position="50% 50%" data-recalc-dims="1" />
  
  <div class="wp-block-cover__inner-container">
    <p>
      <!--StartFragment-->
    </p>
    
    <h2 class="has-foreground-color has-text-color">
      Statement of Purpose
    </h2>
    
    <p class="has-foreground-color has-text-color">
      This blog is intended to document the process of researching video game artificial intelligence using machine learning, with an end goal of developing a tool that will generate Tool Assisted Speedrun (TAS) Bots. <a href="https://www.youtube.com/watch?v=BEcv7BD1q9o">TASBots</a> are predefined hard coded programs that can play single player video games nearly perfectly. The problem is that they must be painstakingly created by hand. This process can take years, as the TASBot developers discover bugs and skips in their chosen game. I believe this process could be expedited by leveraging modern machine learning techniques.
    </p>
    
    <p>
    </p>
  </div>
</div>

<div style="height:20px" aria-hidden="true" class="wp-block-spacer">
</div>

<div class="wp-block-button">
  <a class="wp-block-button__link has-secondary-background-color has-background" href="https://bercribe.home.blog/blog-feed/">View all posts</a>
</div>

<div style="height:20px" aria-hidden="true" class="wp-block-spacer">
</div>

<hr class="wp-block-separator is-style-wide" />

### See My Other Work

<div class="wp-block-button">
  <a class="wp-block-button__link has-secondary-background-color has-background" href="https://matoskawaltz.com/">My Portfolio</a>
</div>
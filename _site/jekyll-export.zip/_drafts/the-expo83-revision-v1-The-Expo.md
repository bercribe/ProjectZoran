---
id: 122
title: The Expo
date: 2021-09-04T03:42:51+00:00
author: mawz
layout: revision
guid: https://bercribehome.wpcomstaging.com/?p=122
permalink: /?p=122
---
I presented my work at the [UMich design expo](https://mdp.engin.umich.edu/design-expo/). It seemed to garner a lot of interest from passers by, especially from those attracted by the video game screenshots. General impressions seemed to be that it was a cool idea and that they&#8217;d like to see further development. Overall, it was a very positive experience for me, sharing a semester&#8217;s worth of work with interested parties.

Something interesting happened as I explained my process to the expo goers over and over again. I was able to refine my explanations based on the questions they were asking over time. Toward the end of the expo, I had my explanation down to a short and concise form that everyone seemed to be able to understand right away. I believe this refinement, in turn, helped improve my own understanding of the project. They say that you reach a new level of understanding in a topic when you can teach it to other people, and that seems to hold true.

I&#8217;d like to extend my thanks to anyone who took interest in my project. In particular, I&#8217;d like to thank the following: my independent research classmates for their interest and feedback in my project. [Matt Thorson](http://www.mattmakesgames.com/) for making Celeste, without whom none of this would be possible. The [Mt. Celeste Climbing Association](https://discordapp.com/invite/AmZBJd8) for making it easy for modders to get started with Celeste. [sc2ad](https://github.com/sc2ad) for all his work on [CelesteBot](https://github.com/sc2ad/CelesteBot/tree/qlearning), which massively bootstrapped my whole project. And [Austin Yarger](https://ayarger.com/), for his continued enthusiasm and support for video games at UMich, as well as his breadth of knowledge and direction over the course of this project. The support of these individuals has made my research possible and enjoyable.

If anyone is reading this blog and would like to start contributing to [CelesteBot](https://github.com/sc2ad/CelesteBot/tree/qlearning), I encourage you to reach out to me or any other members of the Celeste community. My email is mwwaltz at umich dot edu, and my Discord tag is mawz#4488. Shoot me a message, I&#8217;d be happy to help.
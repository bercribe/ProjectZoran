---
id: 8
title: Home
date: 2020-01-10T06:51:32+00:00
author: mawz
layout: page
guid: https://bercribehome.wpcomstaging.com/?page_id=8
sharing_disabled:
  - 'a:1:{i:0;N;}'
switch_like_status:
  - 'a:1:{i:0;N;}'
jabber_published:
  - "1576875134"
---
<div class="wp-block-cover alignfull">
  <img loading="lazy" width="750" height="422" class="wp-block-cover__image-background wp-image-101" alt="" src="https://bercribehome.files.wordpress.com/2020/01/banner-blank.png?resize=750%2C422" style="object-position:50% 50%" data-object-fit="cover" data-object-position="50% 50%" data-recalc-dims="1" />
  
  <div class="wp-block-cover__inner-container">
    <p>
      <!--StartFragment-->
    </p>
    
    <h2 class="has-foreground-color has-text-color">
      Statement of Purpose
    </h2>
    
    <p class="has-foreground-color has-text-color">
      This blog is intended to document the process of researching video game artificial intelligence using machine learning, with an end goal of developing a tool that will generate Tool Assisted Speedrun (TAS) Bots. <a href="https://www.youtube.com/watch?v=BEcv7BD1q9o">TASBots</a> are predefined hard coded programs that can play single player video games nearly perfectly. The problem is that they must be painstakingly created by hand. This process can take years, as the TASBot developers discover bugs and skips in their chosen game. I believe this process could be expedited by leveraging modern machine learning techniques.
    </p>
    
    <p>
    </p>
  </div>
</div>

<div style="height:20px" aria-hidden="true" class="wp-block-spacer">
</div>

<div
			class="wp-block-newspack-blocks-homepage-articles  wpnbha show-image image-aligntop ts-4 is-3 is-landscape "
			style=""
			>
  <div data-posts data-current-post-id="8">
    <article data-post-id="83" class="category-uncategorized type-post" > 
    
    <div class="entry-wrapper">
      <h2 class="entry-title">
        <a href="https://bercribehome.wpcomstaging.com/2019/04/19/the-expo/" rel="bookmark">The Expo</a>
      </h2>
      
      <p>
        I presented my work at the UMich design expo. It seemed to garner a lot of interest from passers by, especially from those attracted by the video game screenshots. General impressions seemed to be that it was a cool idea and that they&#8217;d like to see further development. Overall, it was a very positive experience&hellip;
      </p>
      
      <div class="entry-meta">
        <span class="byline"> by <span class="author vcard"><a class="url fn n" href="https://bercribehome.wpcomstaging.com/author/bercribe/">mawz</a></span> </span><!-- .author-name --><time class="entry-date published" datetime="2019-04-19T14:59:32+00:00">April 19, 2019</time><time class="updated" datetime="2021-09-04T03:43:26+00:00">September 4, 2021</time>
      </div>
      
      <!-- .entry-meta -->
    </div>
    
    <!-- .entry-wrapper --></article> <article data-post-id="76" class="category-uncategorized type-post" > 
    
    <div class="entry-wrapper">
      <h2 class="entry-title">
        <a href="https://bercribehome.wpcomstaging.com/2019/04/12/winding-down/" rel="bookmark">Winding down</a>
      </h2>
      
      <p>
        This week, I finished my research poster for the Umich Design Expo. I think it looks much more professional and gets to its point more concisely. I also decided the CelesteBot README was in need of improvement. I updated it with some &#8220;getting started&#8221; information that would be helpful for new users. Other than that,&hellip;
      </p>
      
      <div class="entry-meta">
        <span class="byline"> by <span class="author vcard"><a class="url fn n" href="https://bercribehome.wpcomstaging.com/author/bercribe/">mawz</a></span> </span><!-- .author-name --><time class="entry-date published" datetime="2019-04-12T17:07:04+00:00">April 12, 2019</time><time class="updated" datetime="2021-09-04T03:44:40+00:00">September 4, 2021</time>
      </div>
      
      <!-- .entry-meta -->
    </div>
    
    <!-- .entry-wrapper --></article>
  </div>
</div>

<div class="wp-block-button">
  <a class="wp-block-button__link has-secondary-background-color has-background" href="https://bercribe.home.blog/blog-feed/">View all posts</a>
</div>

<div style="height:20px" aria-hidden="true" class="wp-block-spacer">
</div>

<hr class="wp-block-separator is-style-wide" />

### See My Other Work

<div class="wp-block-button">
  <a class="wp-block-button__link has-secondary-background-color has-background" href="https://matoskawaltz.com/">My Portfolio</a>
</div>